import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as BoxPointer from 'resource:///org/gnome/shell/ui/boxpointer.js';
import * as AppFavorites from 'resource:///org/gnome/shell/ui/appFavorites.js';

import {launchApp, openUri, spawn, lookupFirstApp, addAppToDesktop, notifyError} from './utils.js';

const MENU_WIDTH = 520;
const MENU_MAX_HEIGHT = 600;
const FLYOUT_WIDTH = 250;
const SEARCH_LIMIT = 40;
const RECENT_LIMIT = 6;
const OPEN_DELAY = 250;
const SUB_DELAY = 150;

const STOP = Clutter.EVENT_STOP;
const PROPAGATE = Clutter.EVENT_PROPAGATE;

// Program folders, in priority order (an app goes in the first one it matches).
const CATEGORIES = [
    {name: 'Games', icon: 'applications-games', match: ['Game']},
    {name: 'Programming', icon: 'applications-development', match: ['Development']},
    {name: 'Graphics', icon: 'applications-graphics', match: ['Graphics']},
    {name: 'Sound & Video', icon: 'applications-multimedia', match: ['AudioVideo', 'Audio', 'Video']},
    {name: 'Internet', icon: 'applications-internet', match: ['Network']},
    {name: 'Office', icon: 'applications-office', match: ['Office']},
    {name: 'Education', icon: 'applications-science', match: ['Education']},
    {name: 'Science', icon: 'applications-science', match: ['Science']},
    {name: 'Settings', icon: 'preferences-system', match: ['Settings']},
    {name: 'System Tools', icon: 'applications-system', match: ['System']},
    {name: 'Accessories', icon: 'applications-accessories', match: ['Utility']},
];
const OTHER = {name: 'Other', icon: 'applications-other', match: []};

function categoryOf(app) {
    const cats = (app.get_app_info()?.get_categories?.() ?? '').split(';');
    return CATEGORIES.find(c => c.match.some(m => cats.includes(m))) ?? OTHER;
}

export class StartMenu {
    constructor(settings, theme) {
        this._settings = settings;
        this._theme = theme;
        this._isOpen = false;
        this._grab = null;
        this._startButton = null;
        this._firstApp = null;
        this._refreshId = 0;
        this._hoverId = 0;
        this._openRow = null;
        this._openCategory = null;

        // Full-screen invisible layer: clicking outside the menu closes it.
        this._backdrop = new St.Widget({reactive: true, visible: false});
        this._backdrop.connect('button-press-event', (_a, ev) => this._onBackdropPress(ev));
        this._backdrop.connect('key-press-event', (_a, ev) => this._onKeyPress(ev));
        Main.uiGroup.add_child(this._backdrop);

        this._box = new St.BoxLayout({
            style_class: 'retro-menu',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
        });
        theme.addRoot(this._box);
        this._backdrop.add_child(this._box);

        this._buildHeader();
        this._buildBody();
        this._buildFooter();

        // Pop-out panels: All Programs, then one folder's apps.
        this._flyout = this._createFlyout();
        this._subFlyout = this._createFlyout();

        this._menuManager = new PopupMenu.PopupMenuManager(this._box);
    }

    setStartButton(button) {
        this._startButton = button;
    }

    // ---------- Hover timing ----------

    _schedule(delay, callback) {
        this._cancelHover();
        this._hoverId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
            this._hoverId = 0;
            callback();
            return GLib.SOURCE_REMOVE;
        });
    }

    _cancelHover() {
        if (this._hoverId) {
            GLib.source_remove(this._hoverId);
            this._hoverId = 0;
        }
    }

    // Hovering normal menu items closes the pop-outs after a short pause.
    _closesFlyoutsOnHover(actor) {
        actor.connect('enter-event', () => {
            if (this._flyout.actor.visible)
                this._schedule(OPEN_DELAY, () => this._closeFlyouts());
            return PROPAGATE;
        });
    }

    // ---------- Main menu layout ----------

    _buildHeader() {
        const header = new St.BoxLayout({style_class: 'retro-menu-header'});
        const avatar = new St.Icon({
            icon_name: 'avatar-default-symbolic',
            icon_size: 40,
            style_class: 'retro-menu-avatar',
        });
        const face = `/var/lib/AccountsService/icons/${GLib.get_user_name()}`;
        if (GLib.file_test(face, GLib.FileTest.EXISTS))
            avatar.gicon = Gio.FileIcon.new(Gio.File.new_for_path(face));
        header.add_child(avatar);

        const realName = GLib.get_real_name();
        header.add_child(new St.Label({
            text: realName && realName !== 'Unknown' ? realName : GLib.get_user_name(),
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'retro-menu-username',
        }));
        this._box.add_child(header);
    }

    _buildBody() {
        const body = new St.BoxLayout({style_class: 'retro-menu-body', y_expand: true});

        const left = new St.BoxLayout({
            style_class: 'retro-menu-left',
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
            y_expand: true,
        });
        this._search = new St.Entry({
            style_class: 'retro-menu-search',
            hint_text: 'Search programs…',
            can_focus: true,
            track_hover: true,
        });
        this._search.clutter_text.connect('text-changed', () => {
            this._closeFlyouts();
            this._refreshLeft();
        });
        this._search.clutter_text.connect('activate', () => this._activateFirst());
        this._closesFlyoutsOnHover(this._search);
        left.add_child(this._search);

        this._list = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            style_class: 'retro-menu-list',
        });
        this._scroll = new St.ScrollView({
            style_class: 'retro-menu-scroll',
            x_expand: true,
            y_expand: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
            overlay_scrollbars: true,
        });
        this._scroll.set_child(this._list);
        left.add_child(this._scroll);

        this._allButton = new St.Button({
            style_class: 'retro-menu-all',
            label: 'All Programs  ▸',
            x_expand: true,
            can_focus: true,
            track_hover: true,
        });
        this._allButton.connect('clicked', () => {
            this._cancelHover();
            if (this._flyout.actor.visible)
                this._closeFlyouts();
            else
                this._openPrograms();
        });
        this._allButton.connect('enter-event', () => {
            if (!this._flyout.actor.visible)
                this._schedule(OPEN_DELAY, () => this._openPrograms());
            else
                this._cancelHover();
            return PROPAGATE;
        });
        left.add_child(this._allButton);
        body.add_child(left);

        const right = new St.BoxLayout({
            style_class: 'retro-menu-right',
            orientation: Clutter.Orientation.VERTICAL,
            y_expand: true,
        });
        const special = dir => GLib.get_user_special_dir(dir) ?? GLib.get_home_dir();
        const openFolder = path => () => openUri(Gio.File.new_for_path(path).get_uri());
        const openApp = (ids, what) => () => {
            const app = lookupFirstApp(ids);
            if (app)
                app.activate();
            else
                notifyError(`No ${what} app was found.`);
        };

        const entries = [
            ['user-home-symbolic', 'Home', openFolder(GLib.get_home_dir()), true],
            ['folder-documents-symbolic', 'Documents', openFolder(special(GLib.UserDirectory.DIRECTORY_DOCUMENTS)), true],
            ['folder-pictures-symbolic', 'Pictures', openFolder(special(GLib.UserDirectory.DIRECTORY_PICTURES)), true],
            ['folder-music-symbolic', 'Music', openFolder(special(GLib.UserDirectory.DIRECTORY_MUSIC)), true],
            ['folder-download-symbolic', 'Downloads', openFolder(special(GLib.UserDirectory.DIRECTORY_DOWNLOAD)), true],
            null,
            ['computer-symbolic', 'Computer', () => openUri('file:///')],
            ['user-trash-symbolic', 'Trash', () => openUri('trash:///')],
            null,
            ['preferences-system-symbolic', 'Settings', openApp(['org.gnome.Settings.desktop'], 'Settings')],
            ['utilities-terminal-symbolic', 'Terminal', openApp(
                ['org.gnome.Ptyxis.desktop', 'org.gnome.Console.desktop', 'org.gnome.Terminal.desktop'], 'terminal')],
            ['system-software-install-symbolic', 'Software', openApp(
                ['io.github.kolunmi.Bazaar.desktop', 'org.gnome.Software.desktop'], 'software store')],
            ['view-app-grid-symbolic', 'Overview', () => Main.overview.show()],
            null,
            ['system-run-symbolic', 'Run…', () => Main.openRunDialog()],
        ];
        for (const entry of entries) {
            if (entry === null)
                right.add_child(new St.Widget({style_class: 'retro-menu-separator', x_expand: true}));
            else
                right.add_child(this._placeButton(...entry));
        }
        body.add_child(right);
        this._box.add_child(body);
    }

    _buildFooter() {
        const footer = new St.BoxLayout({style_class: 'retro-menu-footer'});
        footer.add_child(new St.Widget({x_expand: true}));
        footer.add_child(this._footerButton('system-lock-screen-symbolic', 'Lock',
            () => Main.screenShield?.lock(true)));
        footer.add_child(this._footerButton('system-log-out-symbolic', 'Log Off',
            () => spawn('gnome-session-quit --logout')));
        footer.add_child(this._footerButton('system-reboot-symbolic', 'Restart',
            () => spawn('gnome-session-quit --reboot')));
        footer.add_child(this._footerButton('system-shutdown-symbolic', 'Shut Down',
            () => spawn('gnome-session-quit --power-off')));
        this._box.add_child(footer);
    }

    _placeButton(iconName, text, callback, bold = false) {
        const content = new St.BoxLayout({
            style_class: 'retro-place-content',
            x_expand: true,
            x_align: Clutter.ActorAlign.START,
        });
        content.add_child(new St.Icon({icon_name: iconName, icon_size: 20}));
        content.add_child(new St.Label({
            text,
            y_align: Clutter.ActorAlign.CENTER,
            style_class: bold ? 'retro-place-label-bold' : 'retro-place-label',
        }));
        const button = new St.Button({style_class: 'retro-place', child: content, x_expand: true, can_focus: true});
        button.connect('clicked', () => {
            this.close();
            callback();
        });
        this._closesFlyoutsOnHover(button);
        return button;
    }

    _footerButton(iconName, text, callback) {
        const content = new St.BoxLayout({style_class: 'retro-footer-content'});
        content.add_child(new St.Icon({icon_name: iconName, icon_size: 16}));
        content.add_child(new St.Label({text, y_align: Clutter.ActorAlign.CENTER}));
        const button = new St.Button({style_class: 'retro-footer-button', child: content, can_focus: true});
        button.connect('clicked', () => {
            this.close();
            callback();
        });
        this._closesFlyoutsOnHover(button);
        return button;
    }

    // ---------- App lists ----------

    _allApps() {
        const sys = Shell.AppSystem.get_default();
        const seen = new Set();
        return sys.get_installed()
            .filter(info => {
                try {
                    return info.should_show();
                } catch {
                    return false;
                }
            })
            .map(info => sys.lookup_app(info.get_id()))
            .filter(app => app && !seen.has(app.get_id()) && seen.add(app.get_id()))
            .sort((a, b) => a.get_name().localeCompare(b.get_name()));
    }

    _groupedApps() {
        const groups = new Map();
        for (const app of this._allApps()) {
            const cat = categoryOf(app);
            if (!groups.has(cat))
                groups.set(cat, []);
            groups.get(cat).push(app);
        }
        return [...groups.entries()]
            .map(([cat, apps]) => ({cat, apps}))
            .sort((a, b) => {
                if (a.cat === OTHER)
                    return 1;
                if (b.cat === OTHER)
                    return -1;
                return a.cat.name.localeCompare(b.cat.name);
            });
    }

    _searchApps(query) {
        const terms = query.split(/\s+/);
        const haystack = app => {
            const info = app.get_app_info();
            const keywords = info?.get_keywords?.() ?? [];
            return `${app.get_name()} ${app.get_id()} ${info?.get_generic_name?.() ?? ''} ${keywords.join(' ')}`
                .toLowerCase();
        };
        const starts = app => app.get_name().toLowerCase().startsWith(query) ? 1 : 0;
        return this._allApps()
            .filter(app => terms.every(t => haystack(app).includes(t)))
            .sort((a, b) => starts(b) - starts(a))
            .slice(0, SEARCH_LIMIT);
    }

    _refreshLeft() {
        this._list.destroy_all_children();
        this._firstApp = null;
        const query = this._search.get_text().trim().toLowerCase();

        if (query) {
            this._allButton.hide();
            const results = this._searchApps(query);
            if (!results.length) {
                this._list.add_child(new St.Label({
                    text: 'No programs match that search.',
                    style_class: 'retro-menu-empty',
                }));
                return;
            }
            results.forEach(app => this._list.add_child(this._appItem(app, 'medium')));
            this._firstApp = results[0];
        } else {
            this._allButton.show();
            const favorites = AppFavorites.getAppFavorites().getFavorites();
            favorites.forEach(app => this._list.add_child(this._appItem(app, 'large')));
            const favIds = new Set(favorites.map(app => app.get_id()));
            const recent = Shell.AppUsage.get_default().get_most_used()
                .filter(app => !favIds.has(app.get_id()) && app.get_app_info()?.should_show())
                .slice(0, RECENT_LIMIT);
            if (recent.length && favorites.length)
                this._list.add_child(new St.Widget({style_class: 'retro-menu-separator', x_expand: true}));
            recent.forEach(app => this._list.add_child(this._appItem(app, 'medium')));
            this._firstApp = favorites[0] ?? recent[0] ?? null;
        }
        this._scrollToTop(this._scroll);
    }

    _scrollToTop(scroll) {
        const adjustment = scroll.vadjustment ?? scroll.vscroll?.adjustment;
        if (adjustment)
            adjustment.value = 0;
    }

    _queueRefresh() {
        if (this._refreshId)
            return;
        this._refreshId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._refreshId = 0;
            if (this._isOpen)
                this._refreshLeft();
            return GLib.SOURCE_REMOVE;
        });
    }

    _appButton(app, iconSize, styleClass, labelClass) {
        const content = new St.BoxLayout({
            style_class: `${styleClass}-content`,
            x_expand: true,
            x_align: Clutter.ActorAlign.START,
        });
        content.add_child(app.create_icon_texture(iconSize));
        content.add_child(new St.Label({
            text: app.get_name(),
            y_align: Clutter.ActorAlign.CENTER,
            style_class: labelClass,
        }));
        const button = new St.Button({
            style_class: styleClass,
            child: content,
            x_expand: true,
            can_focus: true,
            button_mask: St.ButtonMask.ONE | St.ButtonMask.THREE,
        });
        button.connect('clicked', (_b, clicked) => {
            if (clicked === 3) {
                this._openAppMenu(button, app);
            } else {
                this.close();
                launchApp(app);
            }
        });
        return button;
    }

    _appItem(app, size) {
        const iconSize = {large: 32, medium: 24}[size];
        const button = this._appButton(app, iconSize, 'retro-app-item', `retro-app-label retro-app-label-${size}`);
        this._closesFlyoutsOnHover(button);
        return button;
    }

    _openAppMenu(button, app) {
        const menu = new PopupMenu.PopupMenu(button, 0.1, St.Side.LEFT);
        Main.uiGroup.add_child(menu.actor);
        menu.actor.hide();
        this._menuManager.addMenu(menu);

        menu.addAction('Open', () => {
            this.close();
            launchApp(app);
        });
        const favorites = AppFavorites.getAppFavorites();
        if (favorites.isFavorite(app.get_id())) {
            menu.addAction('Unpin from menu and quick launch', () => {
                favorites.removeFavorite(app.get_id());
                this._queueRefresh();
            });
        } else {
            menu.addAction('Pin to menu and quick launch', () => {
                favorites.addFavorite(app.get_id());
                this._queueRefresh();
            });
        }
        menu.addAction('Add to desktop', () => addAppToDesktop(app));

        let destroyed = false;
        menu.connect('open-state-changed', (_m, open) => {
            if (open || destroyed)
                return;
            destroyed = true;
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                menu.destroy();
                return GLib.SOURCE_REMOVE;
            });
        });
        menu.open(BoxPointer.PopupAnimation.FULL);
    }

    _activateFirst() {
        if (!this._firstApp)
            return;
        const app = this._firstApp;
        this.close();
        launchApp(app);
    }

    // ---------- Pop-out panels ----------

    _createFlyout() {
        const actor = new St.BoxLayout({
            style_class: 'retro-flyout',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
            visible: false,
        });
        const list = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            style_class: 'retro-flyout-list',
        });
        const scroll = new St.ScrollView({
            x_expand: true,
            y_expand: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
            overlay_scrollbars: true,
        });
        scroll.set_child(list);
        actor.add_child(scroll);
        this._theme.addRoot(actor);
        this._backdrop.add_child(actor);
        return {actor, list, scroll};
    }

    _maxFlyoutHeight() {
        const monitor = Main.layoutManager.primaryMonitor;
        return monitor.height - this._settings.get_int('taskbar-height') - 8;
    }

    // Shows the panel and sizes it to its contents (capped to the screen).
    _sizeFlyout(flyout) {
        const {actor} = flyout;
        actor.set_width(FLYOUT_WIDTH);
        actor.set_height(-1);
        actor.show();
        const [, natural] = actor.get_preferred_height(FLYOUT_WIDTH);
        const height = Math.min(natural, this._maxFlyoutHeight());
        actor.set_height(height);
        this._scrollToTop(flyout.scroll);
        this._backdrop.set_child_above_sibling(actor, null);
        return height;
    }

    _openPrograms() {
        if (!this._isOpen)
            return;
        this._closeSub();
        const {list, actor} = this._flyout;
        list.destroy_all_children();
        for (const group of this._groupedApps())
            list.add_child(this._categoryRow(group));

        const height = this._sizeFlyout(this._flyout);
        const monitor = Main.layoutManager.primaryMonitor;
        const [buttonX, buttonY] = this._allButton.get_transformed_position();
        const buttonRight = buttonX - monitor.x + this._allButton.width;
        const buttonBottom = buttonY - monitor.y + this._allButton.height;
        // Opens upward from the end of the All Programs button, over the menu.
        const y = Math.max(4, Math.min(buttonBottom, this._maxFlyoutHeight()) - height);
        actor.set_position(buttonRight - 4, y);
        this._allButton.add_style_pseudo_class('checked');
    }

    _categoryRow(group) {
        const content = new St.BoxLayout({style_class: 'retro-flyout-item-content', x_expand: true});
        content.add_child(new St.Icon({
            gicon: new Gio.ThemedIcon({names: [group.cat.icon, 'folder']}),
            icon_size: 20,
        }));
        content.add_child(new St.Label({
            text: group.cat.name,
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        }));
        content.add_child(new St.Label({
            text: '▸',
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'retro-flyout-arrow',
        }));
        const row = new St.Button({
            style_class: 'retro-flyout-item',
            child: content,
            x_expand: true,
            can_focus: true,
        });
        row.connect('enter-event', () => {
            if (this._openCategory === group.cat)
                this._cancelHover();
            else
                this._schedule(SUB_DELAY, () => this._openSub(row, group));
            return PROPAGATE;
        });
        row.connect('clicked', () => {
            this._cancelHover();
            this._openSub(row, group);
        });
        return row;
    }

    _openSub(row, group) {
        const {list, actor} = this._subFlyout;
        list.destroy_all_children();
        for (const app of group.apps)
            list.add_child(this._flyoutAppRow(app));

        this._openRow?.remove_style_pseudo_class('checked');
        row.add_style_pseudo_class('checked');
        this._openRow = row;
        this._openCategory = group.cat;

        const height = this._sizeFlyout(this._subFlyout);
        const monitor = Main.layoutManager.primaryMonitor;
        const parent = this._flyout.actor;
        let x = parent.x + parent.width - 4;
        if (x + FLYOUT_WIDTH > monitor.width)
            x = parent.x - FLYOUT_WIDTH + 4;
        const [, rowY] = row.get_transformed_position();
        const y = Math.max(4, Math.min(rowY - monitor.y - 3, this._maxFlyoutHeight() - height));
        actor.set_position(x, y);
    }

    _flyoutAppRow(app) {
        const button = this._appButton(app, 20, 'retro-flyout-item', 'retro-flyout-label');
        button.connect('enter-event', () => {
            this._cancelHover();
            return PROPAGATE;
        });
        return button;
    }

    _closeSub() {
        this._subFlyout.actor.hide();
        this._openRow?.remove_style_pseudo_class('checked');
        this._openRow = null;
        this._openCategory = null;
    }

    _closeFlyouts() {
        this._cancelHover();
        this._closeSub();
        this._flyout.actor.hide();
        this._allButton.remove_style_pseudo_class('checked');
    }

    // ---------- Open / close ----------

    toggle() {
        if (this._isOpen)
            this.close();
        else
            this.open();
    }

    open() {
        if (this._isOpen)
            return;
        if (Main.overview.visible)
            Main.overview.hide();

        const monitor = Main.layoutManager.primaryMonitor;
        const taskbarHeight = this._settings.get_int('taskbar-height');
        const height = Math.min(MENU_MAX_HEIGHT, monitor.height - taskbarHeight - 8);

        this._backdrop.set_position(monitor.x, monitor.y);
        this._backdrop.set_size(monitor.width, monitor.height);
        this._box.set_size(MENU_WIDTH, height);
        this._box.set_position(0, monitor.height - taskbarHeight - height);

        this._isOpen = true;
        this._closeFlyouts();
        this._search.set_text('');
        this._refreshLeft();

        this._backdrop.show();
        Main.uiGroup.set_child_above_sibling(this._backdrop, null);
        this._grab = Main.pushModal(this._backdrop, {actionMode: Shell.ActionMode.POPUP});
        this._search.grab_key_focus();
        this._startButton?.add_style_pseudo_class('checked');
    }

    close() {
        if (!this._isOpen)
            return;
        this._isOpen = false;
        this._closeFlyouts();
        if (this._grab) {
            Main.popModal(this._grab);
            this._grab = null;
        }
        this._backdrop.hide();
        this._startButton?.remove_style_pseudo_class('checked');
    }

    _inside(actor, x, y) {
        if (!actor.visible)
            return false;
        const [ax, ay] = actor.get_transformed_position();
        const [aw, ah] = actor.get_transformed_size();
        return x >= ax && x <= ax + aw && y >= ay && y <= ay + ah;
    }

    _onBackdropPress(event) {
        const [x, y] = event.get_coords();
        if ([this._box, this._flyout.actor, this._subFlyout.actor].some(a => this._inside(a, x, y)))
            return PROPAGATE;
        this.close();
        return STOP;
    }

    _onKeyPress(event) {
        const sym = event.get_key_symbol();
        if (sym === Clutter.KEY_Escape) {
            if (this._subFlyout.actor.visible)
                this._closeSub();
            else if (this._flyout.actor.visible)
                this._closeFlyouts();
            else
                this.close();
            return STOP;
        }
        if (sym === Clutter.KEY_Super_L || sym === Clutter.KEY_Super_R) {
            this.close();
            return STOP;
        }
        if (sym === Clutter.KEY_Down || sym === Clutter.KEY_Up) {
            const focus = global.stage.get_key_focus();
            const root = [this._subFlyout.actor, this._flyout.actor]
                .find(a => a.visible && a.contains(focus)) ?? this._box;
            const direction = sym === Clutter.KEY_Down ? St.DirectionType.DOWN : St.DirectionType.UP;
            root.navigate_focus(focus, direction, false);
            return STOP;
        }
        return PROPAGATE;
    }

    destroy() {
        this.close();
        this._cancelHover();
        if (this._refreshId)
            GLib.source_remove(this._refreshId);
        this._backdrop.destroy();
    }
}
