import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Gtk from 'gi://Gtk';
import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {THEME_KEYS} from './keys.js';
import {IMAGE_DIR, MY_DEFAULT_FILE, captureLook, applyLook, saveLookFile, loadLookFile} from './look.js';

const BG_TOLERANCE = 48;
const MAX_ICON_SIZE = 256;

// Makes the plain colour around the edges of a photo transparent.
// Returns false if the image has no plain, solid border to remove.
function removePlainBackground(srcPath, destPath) {
    let pixbuf = GdkPixbuf.Pixbuf.new_from_file(srcPath);
    const largest = Math.max(pixbuf.width, pixbuf.height);
    if (largest > MAX_ICON_SIZE) {
        const scale = MAX_ICON_SIZE / largest;
        pixbuf = pixbuf.scale_simple(
            Math.max(1, Math.round(pixbuf.width * scale)),
            Math.max(1, Math.round(pixbuf.height * scale)),
            GdkPixbuf.InterpType.BILINEAR);
    }
    if (!pixbuf.has_alpha)
        pixbuf = pixbuf.add_alpha(false, 0, 0, 0);

    const w = pixbuf.width, h = pixbuf.height;
    const stride = pixbuf.rowstride, n = pixbuf.n_channels;
    const px = new Uint8Array(pixbuf.read_pixel_bytes().toArray());
    const at = (x, y) => y * stride + x * n;

    const corners = [[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]].map(([x, y]) => at(x, y));
    if (corners.some(i => px[i + 3] < 200))
        return false; // already has transparency
    const bg = [0, 1, 2].map(c => corners.reduce((sum, i) => sum + px[i + c], 0) / 4);
    const diff = i => Math.max(
        Math.abs(px[i] - bg[0]), Math.abs(px[i + 1] - bg[1]), Math.abs(px[i + 2] - bg[2]));
    if (corners.some(i => diff(i) > BG_TOLERANCE))
        return false; // corners aren't one plain colour

    // Flood-fill inward from the edges so matching colour inside the
    // picture itself is left alone.
    const cleared = new Uint8Array(w * h);
    const queue = new Int32Array(w * h);
    let head = 0, tail = 0;
    const tryPush = (x, y) => {
        const p = y * w + x;
        if (cleared[p])
            return;
        const i = at(x, y);
        if (px[i + 3] === 0 || diff(i) > BG_TOLERANCE)
            return;
        cleared[p] = 1;
        queue[tail++] = p;
    };
    for (let x = 0; x < w; x++) {
        tryPush(x, 0);
        tryPush(x, h - 1);
    }
    for (let y = 0; y < h; y++) {
        tryPush(0, y);
        tryPush(w - 1, y);
    }
    while (head < tail) {
        const p = queue[head++];
        const x = p % w, y = (p - x) / w;
        px[at(x, y) + 3] = 0;
        if (x > 0) tryPush(x - 1, y);
        if (x < w - 1) tryPush(x + 1, y);
        if (y > 0) tryPush(x, y - 1);
        if (y < h - 1) tryPush(x, y + 1);
    }
    if (tail === 0)
        return false;

    // Soften the edge so there's no hard outline left behind.
    for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
            if (cleared[y * w + x])
                continue;
            const touches = (x > 0 && cleared[y * w + x - 1]) || (x < w - 1 && cleared[y * w + x + 1]) ||
                (y > 0 && cleared[(y - 1) * w + x]) || (y < h - 1 && cleared[(y + 1) * w + x]);
            if (!touches)
                continue;
            const i = at(x, y);
            const d = diff(i);
            if (d < BG_TOLERANCE * 2)
                px[i + 3] = Math.round(px[i + 3] * (d - BG_TOLERANCE) / BG_TOLERANCE);
        }
    }

    const out = GdkPixbuf.Pixbuf.new_from_bytes(
        new GLib.Bytes(px), GdkPixbuf.Colorspace.RGB, true, 8, w, h, stride);
    out.savev(destPath, 'png', [], []);
    return true;
}

export default class RetroDeskPrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        this._window = window;
        this._handlers = [];
        window.connect('close-request', () => {
            this._handlers.forEach(id => settings.disconnect(id));
            this._handlers = [];
            return false;
        });
        window.set_default_size(640, 800);

        window.add(this._generalPage(settings));
        window.add(this._appearancePage(settings));
        window.add(this._looksPage(settings));
    }

    _toast(title) {
        this._window.add_toast(new Adw.Toast({title, timeout: 4}));
    }

    // ---------- General ----------

    _generalPage(settings) {
        const page = new Adw.PreferencesPage({title: 'General', icon_name: 'preferences-system-symbolic'});

        const layout = new Adw.PreferencesGroup({title: 'Layout'});
        this._switch(layout, settings, 'hide-top-bar', 'Hide the GNOME top bar',
            'Wi-Fi, sound, power and tray icons move into the taskbar');
        this._switch(layout, settings, 'super-opens-menu', 'Super key opens the start menu',
            'Turn off to get the GNOME overview back on Super');
        this._switch(layout, settings, 'desktop-icons', 'Show desktop icons',
            'Shows what is in your Desktop folder');
        this._switch(layout, settings, 'quick-launch', 'Show quick launch',
            'Pinned apps next to the start button');
        this._switch(layout, settings, 'clock-24h', 'Use a 24-hour clock', null);

        const height = new Adw.SpinRow({
            title: 'Taskbar height',
            adjustment: new Gtk.Adjustment({lower: 28, upper: 56, step_increment: 1, page_increment: 4}),
        });
        settings.bind('taskbar-height', height, 'value', Gio.SettingsBindFlags.DEFAULT);
        layout.add(height);

        page.add(layout);
        return page;
    }

    // ---------- Appearance ----------

    _appearancePage(settings) {
        const page = new Adw.PreferencesPage({title: 'Appearance', icon_name: 'applications-graphics-symbolic'});

        const taskbar = new Adw.PreferencesGroup({title: 'Taskbar'});
        this._color(taskbar, settings, 'taskbar-color-top', 'Top colour');
        this._color(taskbar, settings, 'taskbar-color-bottom', 'Bottom colour');
        this._color(taskbar, settings, 'taskbar-text-color', 'Text and icon colour');
        this._image(taskbar, settings, 'taskbar-image', 'Background image', 'Stretched across the taskbar');
        this._color(taskbar, settings, 'task-color-top', 'Window button top colour');
        this._color(taskbar, settings, 'task-color-bottom', 'Window button bottom colour');
        page.add(taskbar);

        const start = new Adw.PreferencesGroup({title: 'Start button'});
        const label = new Adw.EntryRow({title: 'Button text (leave empty for image only)'});
        settings.bind('start-label', label, 'text', Gio.SettingsBindFlags.DEFAULT);
        start.add(label);
        this._image(start, settings, 'start-icon-image', 'Button image', 'Replaces the default icon', {
            onPicked: path => {
                settings.set_string('start-icon-source', path);
                this._processStartImage(settings, true);
            },
            onCleared: () => {
                settings.set_string('start-icon-source', '');
                settings.set_string('start-icon-image', '');
            },
        });
        const removeBg = new Adw.SwitchRow({
            title: 'Remove plain background',
            subtitle: 'Gets rid of the box around photos so only the picture shows',
        });
        settings.bind('start-icon-remove-bg', removeBg, 'active', Gio.SettingsBindFlags.DEFAULT);
        this._handlers.push(settings.connect('changed::start-icon-remove-bg',
            () => this._processStartImage(settings, true)));
        start.add(removeBg);
        this._color(start, settings, 'start-color-top', 'Top colour');
        this._color(start, settings, 'start-color-bottom', 'Bottom colour');
        this._color(start, settings, 'start-text-color', 'Text colour');
        page.add(start);

        const menu = new Adw.PreferencesGroup({title: 'Start menu'});
        this._image(menu, settings, 'menu-header-image', 'Banner image', 'Shown behind your name at the top');
        this._color(menu, settings, 'menu-header-color-top', 'Banner top colour');
        this._color(menu, settings, 'menu-header-color-bottom', 'Banner bottom colour');
        this._color(menu, settings, 'menu-header-text-color', 'Banner text colour');
        this._color(menu, settings, 'menu-left-color', 'Left column colour');
        this._color(menu, settings, 'menu-right-color', 'Right column colour');
        this._color(menu, settings, 'menu-text-color', 'Text colour', 'Menu items and the All Programs pop-outs');
        this._color(menu, settings, 'menu-hover-text-color', 'Highlighted item text colour');
        this._color(menu, settings, 'menu-footer-text-color', 'Bottom bar text colour', 'Lock, Log Off, Restart, Shut Down');
        page.add(menu);

        const highlight = new Adw.PreferencesGroup({title: 'Highlights and desktop'});
        this._color(highlight, settings, 'accent-color', 'Highlight colour', 'Hovered menu items and selected desktop icons');
        this._color(highlight, settings, 'accent-text-color', 'Highlighted text colour');
        this._color(highlight, settings, 'desktop-text-color', 'Desktop icon text colour');
        page.add(highlight);

        return page;
    }

    _processStartImage(settings, notify) {
        const source = settings.get_string('start-icon-source') || settings.get_string('start-icon-image');
        if (!source || !GLib.file_test(source, GLib.FileTest.EXISTS))
            return;
        if (!settings.get_string('start-icon-source'))
            settings.set_string('start-icon-source', source);

        if (!settings.get_boolean('start-icon-remove-bg')) {
            settings.set_string('start-icon-image', source);
            return;
        }
        GLib.mkdir_with_parents(IMAGE_DIR, 0o755);
        const dest = GLib.build_filenamev([IMAGE_DIR, `start-icon-clean-${Date.now()}.png`]);
        let changed = false;
        try {
            changed = removePlainBackground(source, dest);
        } catch (e) {
            console.error('Retro Desk: background removal failed', e);
        }
        settings.set_string('start-icon-image', changed ? dest : source);
        if (notify && !changed)
            this._toast('No plain background found, so the image is used as it is');
    }

    // ---------- My looks ----------

    _looksPage(settings) {
        const page = new Adw.PreferencesPage({title: 'My looks', icon_name: 'document-save-symbolic'});

        const mine = new Adw.PreferencesGroup({
            title: 'My default look',
            description: 'Saves every colour, image and layout setting, plus your current wallpaper.',
        });
        const saveRow = new Adw.ActionRow({title: 'Save current look as my default'});
        const saveButton = new Gtk.Button({label: 'Save', valign: Gtk.Align.CENTER, css_classes: ['suggested-action']});
        saveRow.add_suffix(saveButton);
        mine.add(saveRow);

        const restoreRow = new Adw.ActionRow({title: 'Go back to my default look'});
        const restoreButton = new Gtk.Button({label: 'Restore', valign: Gtk.Align.CENTER});
        restoreRow.add_suffix(restoreButton);
        mine.add(restoreRow);

        const updateRestore = () => {
            const exists = GLib.file_test(MY_DEFAULT_FILE, GLib.FileTest.EXISTS);
            restoreButton.sensitive = exists;
            restoreRow.subtitle = exists ? '' : 'Save a look first';
        };
        updateRestore();

        saveButton.connect('clicked', () => {
            try {
                saveLookFile(captureLook(settings), MY_DEFAULT_FILE);
                this._toast('Saved as your default look');
            } catch (e) {
                this._toast(`Couldn't save: ${e.message}`);
            }
            updateRestore();
        });
        restoreButton.connect('clicked', () => this._applyFromFile(settings, MY_DEFAULT_FILE, 'Your default look is back'));
        page.add(mine);

        const files = new Adw.PreferencesGroup({
            title: 'Look files',
            description: 'Export to keep a backup or to build your look into the extension. ' +
                'Name the file default-look.json, put it in the extension folder you install from, ' +
                'and run install.sh again: it becomes the look for any fresh install.',
        });
        const exportRow = new Adw.ActionRow({title: 'Export look to a file'});
        const exportButton = new Gtk.Button({label: 'Export…', valign: Gtk.Align.CENTER});
        exportRow.add_suffix(exportButton);
        files.add(exportRow);
        exportButton.connect('clicked', () => this._exportLook(settings));

        const importRow = new Adw.ActionRow({title: 'Load a look from a file'});
        const importButton = new Gtk.Button({label: 'Import…', valign: Gtk.Align.CENTER});
        importRow.add_suffix(importButton);
        files.add(importRow);
        importButton.connect('clicked', () => this._importLook(settings));
        page.add(files);

        const original = new Adw.PreferencesGroup({title: 'Built-in look'});
        const bundled = GLib.build_filenamev([this.path, 'default-look.json']);
        const hasBundled = GLib.file_test(bundled, GLib.FileTest.EXISTS);
        const resetRow = new Adw.ActionRow({
            title: hasBundled
                ? 'Reset to the look built into this extension'
                : 'Reset colours and images to the original Retro Desk look',
            subtitle: hasBundled
                ? 'Restores the colours, images, layout and wallpaper from default-look.json'
                : 'Doesn\'t change your wallpaper or your saved default',
        });
        const resetButton = new Gtk.Button({label: 'Reset', valign: Gtk.Align.CENTER, css_classes: ['destructive-action']});
        resetButton.connect('clicked', () => {
            if (hasBundled) {
                this._applyFromFile(settings, bundled, 'Built-in look restored');
            } else {
                THEME_KEYS.forEach(key => settings.reset(key));
                this._toast('Original look restored');
            }
        });
        resetRow.add_suffix(resetButton);
        original.add(resetRow);
        page.add(original);

        return page;
    }

    _jsonFilters() {
        const filter = new Gtk.FileFilter({name: 'Retro Desk looks (.json)'});
        filter.add_pattern('*.json');
        const filters = new Gio.ListStore({item_type: Gtk.FileFilter});
        filters.append(filter);
        return [filters, filter];
    }

    _exportLook(settings) {
        const [filters, filter] = this._jsonFilters();
        const dialog = new Gtk.FileDialog({
            title: 'Export look',
            initial_name: 'default-look.json',
            filters,
            default_filter: filter,
        });
        dialog.save(this._window, null, (d, result) => {
            let file;
            try {
                file = d.save_finish(result);
            } catch {
                return;
            }
            try {
                saveLookFile(captureLook(settings), file.get_path());
                this._toast(`Exported to ${file.get_basename()}`);
            } catch (e) {
                this._toast(`Couldn't export: ${e.message}`);
            }
        });
    }

    _importLook(settings) {
        const [filters, filter] = this._jsonFilters();
        const dialog = new Gtk.FileDialog({title: 'Import look', filters, default_filter: filter});
        dialog.open(this._window, null, (d, result) => {
            let file;
            try {
                file = d.open_finish(result);
            } catch {
                return;
            }
            this._applyFromFile(settings, file.get_path(), 'Look loaded');
        });
    }

    _applyFromFile(settings, path, message) {
        try {
            applyLook(settings, loadLookFile(path));
            this._toast(message);
        } catch (e) {
            this._toast(`Couldn't load that look: ${e.message}`);
        }
    }

    // ---------- Row helpers ----------

    _switch(group, settings, key, title, subtitle) {
        const row = new Adw.SwitchRow({title});
        if (subtitle)
            row.subtitle = subtitle;
        settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(row);
    }

    _color(group, settings, key, title, subtitle = null) {
        const row = new Adw.ActionRow({title});
        if (subtitle)
            row.subtitle = subtitle;
        const button = new Gtk.ColorDialogButton({
            dialog: new Gtk.ColorDialog({title, with_alpha: true}),
            valign: Gtk.Align.CENTER,
        });
        const load = () => {
            const rgba = new Gdk.RGBA();
            if (rgba.parse(settings.get_string(key)) && !rgba.equal(button.get_rgba()))
                button.set_rgba(rgba);
        };
        load();
        button.connect('notify::rgba', () => {
            const value = button.get_rgba().to_string();
            if (value !== settings.get_string(key))
                settings.set_string(key, value);
        });
        this._handlers.push(settings.connect(`changed::${key}`, load));
        row.add_suffix(button);
        row.activatable_widget = button;
        group.add(row);
    }

    _image(group, settings, key, title, hint, {onPicked = null, onCleared = null} = {}) {
        const row = new Adw.ActionRow({title});
        const choose = new Gtk.Button({
            icon_name: 'document-open-symbolic',
            valign: Gtk.Align.CENTER,
            tooltip_text: 'Choose image',
            css_classes: ['flat'],
        });
        const clear = new Gtk.Button({
            icon_name: 'edit-clear-symbolic',
            valign: Gtk.Align.CENTER,
            tooltip_text: 'Remove image',
            css_classes: ['flat'],
        });
        const update = () => {
            const path = settings.get_string(key);
            row.subtitle = path ? GLib.path_get_basename(path) : hint;
            clear.sensitive = path.length > 0;
        };
        update();
        this._handlers.push(settings.connect(`changed::${key}`, update));

        choose.connect('clicked', () => {
            const filter = new Gtk.FileFilter({name: 'Images'});
            filter.add_pixbuf_formats();
            filter.add_mime_type('image/svg+xml');
            const filters = new Gio.ListStore({item_type: Gtk.FileFilter});
            filters.append(filter);
            const dialog = new Gtk.FileDialog({title, filters, default_filter: filter});
            dialog.open(this._window, null, (d, result) => {
                let file;
                try {
                    file = d.open_finish(result);
                } catch {
                    return; // cancelled
                }
                const saved = this._copyImage(file, key);
                if (onPicked)
                    onPicked(saved);
                else
                    settings.set_string(key, saved);
            });
        });
        clear.connect('clicked', () => {
            if (onCleared)
                onCleared();
            else
                settings.set_string(key, '');
        });

        row.add_suffix(choose);
        row.add_suffix(clear);
        group.add(row);
    }

    _copyImage(file, key) {
        try {
            GLib.mkdir_with_parents(IMAGE_DIR, 0o755);
            const base = file.get_basename().replace(/[^\w.-]/g, '_');
            const dest = Gio.File.new_for_path(
                GLib.build_filenamev([IMAGE_DIR, `${key}-${Date.now()}-${base}`]));
            file.copy(dest, Gio.FileCopyFlags.OVERWRITE, null, null);
            return dest.get_path();
        } catch (e) {
            console.error('Retro Desk: could not copy image', e);
            return file.get_path();
        }
    }
}
