import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {ThemeManager} from './theme.js';
import {Taskbar} from './taskbar.js';
import {StartMenu} from './startMenu.js';
import {DesktopIcons} from './desktopIcons.js';
import {applyLook, loadLookFile} from './look.js';

export default class RetroDeskExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._applyBundledLook();
        this._theme = new ThemeManager(this._settings);
        this._menu = new StartMenu(this._settings, this._theme);
        this._taskbar = new Taskbar(this._settings, this._menu, this._theme);
        this._desktop = null;
        this._topBarHidden = false;
        this._overlayId = 0;
        this._overlayBlocked = 0;

        this._settingIds = [
            this._settings.connect('changed::hide-top-bar', () => this._syncTopBar()),
            this._settings.connect('changed::super-opens-menu', () => this._syncSuperKey()),
            this._settings.connect('changed::desktop-icons', () => this._syncDesktopIcons()),
        ];

        this._syncTopBar();
        this._syncSuperKey();
        this._syncDesktopIcons();

        // Start on the desktop rather than the overview.
        this._startupId = 0;
        if (Main.layoutManager._startingUp) {
            this._startupId = Main.layoutManager.connect('startup-complete', () => {
                Main.layoutManager.disconnect(this._startupId);
                this._startupId = 0;
                Main.overview.hide();
            });
        }
    }

    disable() {
        if (this._startupId) {
            Main.layoutManager.disconnect(this._startupId);
            this._startupId = 0;
        }
        this._settingIds.forEach(id => this._settings.disconnect(id));
        this._settingIds = [];

        this._setSuperKey(false);
        this._setTopBarHidden(false);
        this._desktop?.destroy();
        this._desktop = null;
        this._taskbar.destroy();
        this._taskbar = null;
        this._menu.destroy();
        this._menu = null;
        this._theme.destroy();
        this._theme = null;
        this._settings = null;
    }

    // Applies the default-look.json shipped with the extension when it's new
    // or has been updated (its "revision" number went up).
    _applyBundledLook() {
        const path = GLib.build_filenamev([this.path, 'default-look.json']);
        if (!GLib.file_test(path, GLib.FileTest.EXISTS))
            return;
        try {
            const look = loadLookFile(path);
            const revision = look.revision ?? 1;
            if (revision <= this._settings.get_int('default-look-revision'))
                return;
            applyLook(this._settings, look);
            this._settings.set_int('default-look-revision', revision);
        } catch (e) {
            console.error('Retro Desk: could not apply default-look.json', e);
        }
    }

    // ---- Top bar ----

    _syncTopBar() {
        this._setTopBarHidden(this._settings.get_boolean('hide-top-bar'));
    }

    _setTopBarHidden(hide) {
        if (hide === this._topBarHidden)
            return;
        const box = Main.layoutManager.panelBox;
        if (hide) {
            // Keep Wi-Fi, sound, power and tray icons by moving them to the taskbar.
            this._taskbar.adoptPanelIndicators(true);
            Main.layoutManager._untrackActor(box);
            box.hide();
        } else {
            box.show();
            Main.layoutManager._trackActor(box, {affectsStruts: true, trackFullscreen: true});
            this._taskbar.adoptPanelIndicators(false);
        }
        this._topBarHidden = hide;
    }

    // ---- Super key ----

    _syncSuperKey() {
        this._setSuperKey(this._settings.get_boolean('super-opens-menu'));
    }

    _setSuperKey(on) {
        if (on && !this._overlayId) {
            const original = GObject.signal_handler_find(global.display, {signalId: 'overlay-key'});
            if (original) {
                GObject.signal_handler_block(global.display, original);
                this._overlayBlocked = original;
            }
            this._overlayId = global.display.connect('overlay-key', () => this._menu.toggle());
        } else if (!on && this._overlayId) {
            global.display.disconnect(this._overlayId);
            this._overlayId = 0;
            if (this._overlayBlocked) {
                GObject.signal_handler_unblock(global.display, this._overlayBlocked);
                this._overlayBlocked = 0;
            }
        }
    }

    // ---- Desktop icons ----

    _syncDesktopIcons() {
        const on = this._settings.get_boolean('desktop-icons');
        if (on && !this._desktop)
            this._desktop = new DesktopIcons(this._theme);
        else if (!on && this._desktop) {
            this._desktop.destroy();
            this._desktop = null;
        }
    }
}
