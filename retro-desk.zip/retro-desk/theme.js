import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';

import {THEME_KEYS} from './keys.js';

const COLOR_RE = /^(#[0-9a-fA-F]{3,8}|rgba?\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+\s*(,\s*[\d.]+\s*)?\))$/;

function withAlpha(color, alpha) {
    let m = color.match(/^#([0-9a-fA-F]{6})/);
    if (m) {
        const n = parseInt(m[1], 16);
        return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
    }
    m = color.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/);
    if (m)
        return `rgba(${m[1]}, ${m[2]}, ${m[3]}, ${alpha})`;
    return `rgba(26, 138, 124, ${alpha})`;
}

// Writes the user's colours and images to a small stylesheet that is
// loaded on top of stylesheet.css, and reloads it whenever a setting changes.
export class ThemeManager {
    constructor(settings) {
        this._settings = settings;
        this._roots = new Set();
        this._file = null;
        this._applyId = 0;
        this._changedId = settings.connect('changed', (_s, key) => {
            if (THEME_KEYS.includes(key))
                this._queueApply();
        });
        this.apply();
    }

    addRoot(actor) {
        this._roots.add(actor);
        actor.add_style_class_name('retro-themed');
        actor.connect('destroy', () => this._roots.delete(actor));
    }

    _queueApply() {
        if (this._applyId)
            GLib.source_remove(this._applyId);
        this._applyId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 150, () => {
            this._applyId = 0;
            this.apply();
            return GLib.SOURCE_REMOVE;
        });
    }

    _color(key) {
        const value = this._settings.get_string(key).trim();
        return COLOR_RE.test(value) ? value : this._settings.get_default_value(key).unpack();
    }

    _image(key) {
        const path = this._settings.get_string(key).trim();
        if (!path || /["\\\n]/.test(path) || !GLib.file_test(path, GLib.FileTest.EXISTS))
            return '';
        return `background-image: url("${path}"); background-size: cover;`;
    }

    _css() {
        const c = k => this._color(k);
        const accent = c('accent-color');
        return `
.retro-themed.retro-taskbar {
  background-gradient-start: ${c('taskbar-color-top')};
  background-gradient-end: ${c('taskbar-color-bottom')};
  color: ${c('taskbar-text-color')};
  ${this._image('taskbar-image')}
}
.retro-themed .retro-tray .panel-button,
.retro-themed .retro-clock,
.retro-themed .retro-show-desktop { color: ${c('taskbar-text-color')}; }
.retro-themed .retro-start-button {
  background-gradient-start: ${c('start-color-top')};
  background-gradient-end: ${c('start-color-bottom')};
  color: ${c('start-text-color')};
}
.retro-themed .retro-start-icon { color: ${c('start-text-color')}; }
.retro-themed .retro-task {
  background-gradient-start: ${c('task-color-top')};
  background-gradient-end: ${c('task-color-bottom')};
  color: ${c('taskbar-text-color')};
}
.retro-themed.retro-menu {
  color: ${c('menu-text-color')};
  background-color: ${c('menu-left-color')};
}
.retro-themed .retro-menu-header {
  background-gradient-start: ${c('menu-header-color-top')};
  background-gradient-end: ${c('menu-header-color-bottom')};
  ${this._image('menu-header-image')}
}
.retro-themed .retro-menu-username { color: ${c('menu-header-text-color')}; }
.retro-themed .retro-menu-left { background-color: ${c('menu-left-color')}; }
.retro-themed .retro-menu-right { background-color: ${c('menu-right-color')}; }
.retro-themed .retro-menu-footer {
  background-gradient-start: ${c('taskbar-color-top')};
  background-gradient-end: ${c('taskbar-color-bottom')};
  color: ${c('menu-footer-text-color')};
}
.retro-themed .retro-menu-search { color: ${c('menu-text-color')}; }
.retro-themed .retro-menu-search:focus { border-color: ${accent}; }
.retro-themed.retro-flyout {
  background-color: ${c('menu-left-color')};
  color: ${c('menu-text-color')};
}
.retro-themed .retro-app-item:hover,
.retro-themed .retro-app-item:focus,
.retro-themed .retro-place:hover,
.retro-themed .retro-place:focus,
.retro-themed .retro-menu-all:hover,
.retro-themed .retro-menu-all:checked,
.retro-themed .retro-flyout-item:hover,
.retro-themed .retro-flyout-item:focus,
.retro-themed .retro-flyout-item:checked {
  background-color: ${accent};
  color: ${c('menu-hover-text-color')};
}
.retro-themed .retro-desktop-icon-label { color: ${c('desktop-text-color')}; }
.retro-themed .retro-desktop-icon:selected .retro-desktop-icon-label {
  background-color: ${accent};
  color: ${c('accent-text-color')};
}
.retro-themed .retro-rubberband {
  background-color: ${withAlpha(accent, 0.25)};
  border-color: ${accent};
}
`;
    }

    apply() {
        const dir = GLib.build_filenamev([GLib.get_user_cache_dir(), 'retro-desk']);
        GLib.mkdir_with_parents(dir, 0o755);
        // A new file name each time makes St re-read it instead of using a cached copy.
        const path = GLib.build_filenamev([dir, `theme-${Date.now()}.css`]);
        try {
            GLib.file_set_contents(path, this._css());
        } catch (e) {
            console.error('Retro Desk: could not write theme', e);
            return;
        }

        const theme = St.ThemeContext.get_for_stage(global.stage).get_theme();
        this._unload(theme);
        this._file = Gio.File.new_for_path(path);
        theme.load_stylesheet(this._file);

        // Nudge widgets to restyle with the new sheet.
        for (const actor of this._roots) {
            actor.remove_style_class_name('retro-themed');
            actor.add_style_class_name('retro-themed');
        }
    }

    _unload(theme) {
        if (!this._file)
            return;
        theme.unload_stylesheet(this._file);
        try {
            this._file.delete(null);
        } catch {}
        this._file = null;
    }

    destroy() {
        if (this._applyId)
            GLib.source_remove(this._applyId);
        this._settings.disconnect(this._changedId);
        this._unload(St.ThemeContext.get_for_stage(global.stage).get_theme());
        this._roots.clear();
    }
}
