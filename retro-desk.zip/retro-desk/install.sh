#!/usr/bin/env bash
# Installs Retro Desk for the current user.
set -e

UUID="retro-desk@local"
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/gnome-shell/extensions/$UUID"

mkdir -p "$DEST"
cp "$SRC"/metadata.json "$SRC"/*.js "$SRC"/stylesheet.css "$DEST"/
rm -f "$DEST/install.sh"
cp -r "$SRC"/schemas "$DEST"/
if [ -f "$SRC/default-look.json" ]; then
    cp "$SRC/default-look.json" "$DEST"/
    echo "Bundled your default-look.json"
fi
glib-compile-schemas "$DEST/schemas"

echo
echo "Installed to $DEST"
echo
echo "Next:"
echo "  1. Log out and log back in."
echo "  2. Run: gnome-extensions enable $UUID"
echo "  3. Settings: gnome-extensions prefs $UUID"
