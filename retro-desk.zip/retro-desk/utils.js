import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const TITLE = 'Retro Desk';

export function notifyError(message) {
    Main.notifyError(TITLE, message);
}

export function launchContext() {
    return global.create_app_launch_context(0, -1);
}

export function openUri(uri) {
    try {
        Gio.AppInfo.launch_default_for_uri(uri, launchContext());
    } catch (e) {
        notifyError(`Couldn't open ${uri}: ${e.message}`);
    }
}

export function spawn(command) {
    try {
        GLib.spawn_command_line_async(command);
    } catch (e) {
        notifyError(`Couldn't run "${command}": ${e.message}`);
    }
}

// Classic behaviour: clicking an app launches it. If it is already running
// and supports multiple windows, open another window.
export function launchApp(app) {
    if (app.get_n_windows() > 0 && app.can_open_new_window())
        app.open_new_window(-1);
    else
        app.activate();
}

export function lookupFirstApp(ids) {
    const sys = Shell.AppSystem.get_default();
    for (const id of ids) {
        const app = sys.lookup_app(id);
        if (app)
            return app;
    }
    return null;
}

export function desktopDir() {
    let path = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP);
    if (!path || path === GLib.get_home_dir())
        path = GLib.build_filenamev([GLib.get_home_dir(), 'Desktop']);
    GLib.mkdir_with_parents(path, 0o755);
    return path;
}

export function addAppToDesktop(app) {
    const info = app.get_app_info();
    const src = info?.get_filename?.();
    if (!src) {
        notifyError(`${app.get_name()} can't be added to the desktop.`);
        return;
    }
    const dest = Gio.File.new_for_path(
        GLib.build_filenamev([desktopDir(), GLib.path_get_basename(src)]));
    try {
        Gio.File.new_for_path(src).copy(dest, Gio.FileCopyFlags.OVERWRITE, null, null);
        dest.set_attribute_uint32('unix::mode', 0o755, Gio.FileQueryInfoFlags.NONE, null);
    } catch (e) {
        notifyError(`Couldn't add ${app.get_name()} to the desktop: ${e.message}`);
    }
}

// Mutter changed the maximize API around GNOME 49, so support both forms.
export function isMaximized(win) {
    if (typeof win.is_maximized === 'function')
        return win.is_maximized();
    return win.get_maximized() === Meta.MaximizeFlags.BOTH;
}

export function maximize(win) {
    try {
        win.maximize(Meta.MaximizeFlags?.BOTH ?? 3);
    } catch {
        win.maximize();
    }
}

export function unmaximize(win) {
    try {
        win.unmaximize(Meta.MaximizeFlags?.BOTH ?? 3);
    } catch {
        win.unmaximize();
    }
}
