// Saving and restoring a whole "look": every colour and layout setting,
// the chosen images, and the desktop wallpaper, bundled into one JSON file.
// Uses only Gio/GLib so both the shell and the settings window can load it.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

import {THEME_KEYS, LAYOUT_KEYS, IMAGE_KEYS} from './keys.js';

export const DATA_DIR = GLib.build_filenamev([GLib.get_user_data_dir(), 'retro-desk']);
export const IMAGE_DIR = GLib.build_filenamev([DATA_DIR, 'images']);
export const MY_DEFAULT_FILE = GLib.build_filenamev([DATA_DIR, 'my-default-look.json']);

const WALLPAPER_SCHEMA = 'org.gnome.desktop.background';
const WALLPAPER_KEYS = ['picture-uri', 'picture-uri-dark'];

function encodeFile(path) {
    const [, bytes] = GLib.file_get_contents(path);
    return GLib.base64_encode(bytes);
}

function writeImage(name, data) {
    GLib.mkdir_with_parents(IMAGE_DIR, 0o755);
    const safe = name.replace(/[^\w.-]/g, '_');
    const path = GLib.build_filenamev([IMAGE_DIR, `${Date.now()}-${safe}`]);
    GLib.file_set_contents(path, GLib.base64_decode(data));
    return path;
}

export function captureLook(settings) {
    // "revision" always goes up, so a newer exported look replaces an older one on install.
    const look = {
        format: 'retro-desk-look',
        version: 1,
        revision: Math.floor(Date.now() / 1000),
        settings: {},
        images: {},
        wallpaper: null,
    };

    for (const key of [...THEME_KEYS, ...LAYOUT_KEYS])
        look.settings[key] = settings.get_value(key).deep_unpack();

    for (const key of IMAGE_KEYS) {
        const path = settings.get_string(key);
        if (path && GLib.file_test(path, GLib.FileTest.EXISTS))
            look.images[key] = {name: GLib.path_get_basename(path), data: encodeFile(path)};
    }

    // Wallpaper (light and dark variants; stored once if they're the same file)
    const bg = new Gio.Settings({schema_id: WALLPAPER_SCHEMA});
    const wallpaper = {options: bg.get_string('picture-options'), files: {}};
    const seen = new Map();
    for (const key of WALLPAPER_KEYS) {
        const path = Gio.File.new_for_uri(bg.get_string(key)).get_path();
        if (!path || !GLib.file_test(path, GLib.FileTest.EXISTS))
            continue;
        if (seen.has(path)) {
            wallpaper.files[key] = {sameAs: seen.get(path)};
        } else {
            wallpaper.files[key] = {name: GLib.path_get_basename(path), data: encodeFile(path)};
            seen.set(path, key);
        }
    }
    if (Object.keys(wallpaper.files).length)
        look.wallpaper = wallpaper;

    return look;
}

export function applyLook(settings, look) {
    if (look?.format !== 'retro-desk-look')
        throw new Error('This file is not a Retro Desk look.');

    const schema = settings.settings_schema;
    for (const [key, value] of Object.entries(look.settings ?? {})) {
        if (!schema.has_key(key) || IMAGE_KEYS.includes(key))
            continue;
        const type = settings.get_value(key).get_type_string();
        settings.set_value(key, new GLib.Variant(type, value));
    }

    for (const key of IMAGE_KEYS) {
        const image = look.images?.[key];
        settings.set_string(key, image ? writeImage(image.name, image.data) : '');
    }

    if (look.wallpaper) {
        const bg = new Gio.Settings({schema_id: WALLPAPER_SCHEMA});
        const written = {};
        for (const key of WALLPAPER_KEYS) {
            const entry = look.wallpaper.files?.[key];
            if (!entry)
                continue;
            const path = entry.sameAs ? written[entry.sameAs] : writeImage(entry.name, entry.data);
            if (!path)
                continue;
            written[key] = path;
            bg.set_string(key, Gio.File.new_for_path(path).get_uri());
        }
        if (look.wallpaper.options)
            bg.set_string('picture-options', look.wallpaper.options);
    }
}

export function saveLookFile(look, path) {
    GLib.mkdir_with_parents(GLib.path_get_dirname(path), 0o755);
    GLib.file_set_contents(path, JSON.stringify(look));
}

export function loadLookFile(path) {
    const [, bytes] = GLib.file_get_contents(path);
    return JSON.parse(new TextDecoder().decode(bytes));
}
