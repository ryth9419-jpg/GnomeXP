// Settings keys that control appearance. No imports here, so both the
// shell side and the preferences window can use this file.
export const THEME_KEYS = [
    'taskbar-color-top',
    'taskbar-color-bottom',
    'taskbar-text-color',
    'taskbar-image',
    'start-color-top',
    'start-color-bottom',
    'start-text-color',
    'start-label',
    'start-icon-image',
    'start-icon-source',
    'start-icon-remove-bg',
    'task-color-top',
    'task-color-bottom',
    'menu-header-color-top',
    'menu-header-color-bottom',
    'menu-header-text-color',
    'menu-header-image',
    'menu-left-color',
    'menu-right-color',
    'menu-text-color',
    'menu-hover-text-color',
    'menu-footer-text-color',
    'accent-color',
    'accent-text-color',
    'desktop-text-color',
];

export const LAYOUT_KEYS = [
    'hide-top-bar',
    'super-opens-menu',
    'desktop-icons',
    'quick-launch',
    'clock-24h',
    'taskbar-height',
];

export const IMAGE_KEYS = [
    'taskbar-image',
    'start-icon-image',
    'start-icon-source',
    'menu-header-image',
];
