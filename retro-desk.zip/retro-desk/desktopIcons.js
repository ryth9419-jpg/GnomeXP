import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Pango from 'gi://Pango';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as BoxPointer from 'resource:///org/gnome/shell/ui/boxpointer.js';

import {desktopDir, openUri, spawn, launchContext, notifyError} from './utils.js';

const CELL_W = 100;
const CELL_H = 96;
const MARGIN = 10;
const ICON_SIZE = 48;
const DRAG_THRESHOLD = 5;
const ATTRS = 'standard::name,standard::display-name,standard::icon,standard::type,standard::is-hidden,standard::is-backup';

const STOP = Clutter.EVENT_STOP;
const PROPAGATE = Clutter.EVENT_PROPAGATE;

export class DesktopIcons {
    constructor(theme) {
        this._dir = Gio.File.new_for_path(desktopDir());
        this._configFile = GLib.build_filenamev([GLib.get_user_config_dir(), 'retro-desk', 'positions.json']);
        this._positions = this._loadPositions();
        this._icons = [];
        this._selected = new Set();
        this._drag = null;
        this._band = null;
        this._grab = null;
        this._reloadId = 0;
        this._signals = [];

        // Sits just above the wallpaper and below all windows.
        this._layer = new St.Widget({reactive: true, style_class: 'retro-desktop-layer'});
        theme.addRoot(this._layer);
        this._iconBox = new Clutter.Actor();
        this._layer.add_child(this._iconBox);
        this._bandActor = new St.Widget({style_class: 'retro-rubberband', visible: false});
        this._layer.add_child(this._bandActor);

        this._layer.connect('button-press-event', (_a, ev) => this._onLayerPress(ev));
        this._layer.connect('motion-event', (_a, ev) => this._onMotion(ev));
        this._layer.connect('button-release-event', (_a, ev) => this._onRelease(ev));

        const bg = Main.layoutManager._backgroundGroup;
        bg.add_child(this._layer);
        // Keep the icons above the wallpaper when the wallpaper changes.
        this._connect(bg, 'child-added', (_g, child) => {
            if (child !== this._layer)
                bg.set_child_above_sibling(this._layer, null);
        });

        this._menuManager = new PopupMenu.PopupMenuManager(this._layer);

        this._monitor = this._dir.monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, null);
        this._monitor.connect('changed', () => this._queueReload());
        this._connect(global.display, 'workareas-changed', () => this._relayout());
        this._connect(Main.layoutManager, 'monitors-changed', () => this._relayout());

        this._reload();
    }

    _connect(obj, signal, callback) {
        this._signals.push([obj, obj.connect(signal, callback)]);
    }

    // ---- Positions ----

    _loadPositions() {
        try {
            const [ok, bytes] = GLib.file_get_contents(this._configFile);
            if (ok)
                return JSON.parse(new TextDecoder().decode(bytes));
        } catch {}
        return {};
    }

    _savePositions() {
        try {
            GLib.mkdir_with_parents(GLib.path_get_dirname(this._configFile), 0o755);
            GLib.file_set_contents(this._configFile, JSON.stringify(this._positions));
        } catch (e) {
            console.error('Retro Desk: could not save icon positions', e);
        }
    }

    _geometry() {
        const index = Main.layoutManager.primaryIndex;
        const mon = Main.layoutManager.monitors[index];
        const area = Main.layoutManager.getWorkAreaForMonitor(index);
        return {
            mon,
            ox: area.x - mon.x + MARGIN,
            oy: area.y - mon.y + MARGIN,
            cols: Math.max(1, Math.floor((area.width - 2 * MARGIN) / CELL_W)),
            rows: Math.max(1, Math.floor((area.height - 2 * MARGIN) / CELL_H)),
        };
    }

    // ---- Loading ----

    _queueReload() {
        if (this._reloadId)
            GLib.source_remove(this._reloadId);
        this._reloadId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 250, () => {
            if (this._drag || this._band)
                return GLib.SOURCE_CONTINUE;
            this._reloadId = 0;
            this._reload();
            return GLib.SOURCE_REMOVE;
        });
    }

    _reload() {
        this._iconBox.destroy_all_children();
        this._icons = [];
        this._selected.clear();

        const infos = [];
        try {
            const enumerator = this._dir.enumerate_children(ATTRS, Gio.FileQueryInfoFlags.NONE, null);
            let info;
            while ((info = enumerator.next_file(null)) !== null) {
                if (!info.get_is_hidden() && !info.get_is_backup())
                    infos.push(info);
            }
            enumerator.close(null);
        } catch (e) {
            console.error('Retro Desk: could not read the Desktop folder', e);
        }
        infos.sort((a, b) => a.get_display_name().localeCompare(b.get_display_name()));
        for (const info of infos)
            this._icons.push(this._makeIcon(info));
        this._relayout();
    }

    _makeIcon(info) {
        const name = info.get_name();
        const file = this._dir.get_child(name);
        let text = info.get_display_name();
        let gicon = info.get_icon();
        let appInfo = null;

        if (name.endsWith('.desktop')) {
            try {
                appInfo = Gio.DesktopAppInfo.new_from_filename(file.get_path());
            } catch {}
            if (appInfo) {
                text = appInfo.get_name();
                gicon = appInfo.get_icon() ?? gicon;
            }
        }

        const actor = new St.BoxLayout({
            style_class: 'retro-desktop-icon',
            orientation: Clutter.Orientation.VERTICAL,
            reactive: true,
            track_hover: true,
            width: CELL_W - 8,
        });
        actor.add_child(new St.Icon({
            gicon,
            icon_size: ICON_SIZE,
            x_align: Clutter.ActorAlign.CENTER,
        }));
        const label = new St.Label({
            text,
            x_align: Clutter.ActorAlign.CENTER,
            style_class: 'retro-desktop-icon-label',
        });
        label.clutter_text.line_alignment = Pango.Alignment.CENTER;
        label.clutter_text.line_wrap_mode = Pango.WrapMode.WORD_CHAR;
        label.clutter_text.ellipsize = Pango.EllipsizeMode.END;
        actor.add_child(label);

        const item = {name, file, appInfo, actor, label, col: 0, row: 0};
        actor.connect('button-press-event', (_a, ev) => this._onIconPress(item, ev));
        actor.connect('motion-event', (_a, ev) => this._onMotion(ev));
        actor.connect('button-release-event', (_a, ev) => this._onRelease(ev));
        this._iconBox.add_child(actor);
        return item;
    }

    // ---- Layout ----

    _relayout() {
        const g = this._geometry();
        this._layer.set_position(g.mon.x, g.mon.y);
        this._layer.set_size(g.mon.width, g.mon.height);

        const taken = new Set();
        const unplaced = [];
        for (const item of this._icons) {
            const saved = this._positions[item.name];
            if (saved && saved[0] < g.cols && saved[1] < g.rows && !taken.has(`${saved[0]},${saved[1]}`)) {
                [item.col, item.row] = saved;
                taken.add(`${item.col},${item.row}`);
            } else {
                unplaced.push(item);
            }
        }
        // Fill top-to-bottom, then the next column.
        for (const item of unplaced) {
            [item.col, item.row] = this._firstFree(taken, g);
            taken.add(`${item.col},${item.row}`);
        }
        this._icons.forEach(item => this._place(item, g));
    }

    _place(item, g) {
        item.actor.set_position(g.ox + item.col * CELL_W + 4, g.oy + item.row * CELL_H);
    }

    _firstFree(taken, g) {
        for (let c = 0; c < g.cols; c++) {
            for (let r = 0; r < g.rows; r++) {
                if (!taken.has(`${c},${r}`))
                    return [c, r];
            }
        }
        return [0, 0];
    }

    _nearestFree(col, row, taken, g) {
        if (!taken.has(`${col},${row}`))
            return [col, row];
        for (let d = 1; d < g.cols + g.rows; d++) {
            for (let dc = -d; dc <= d; dc++) {
                for (let dr = -d; dr <= d; dr++) {
                    if (Math.max(Math.abs(dc), Math.abs(dr)) !== d)
                        continue;
                    const c = col + dc, r = row + dr;
                    if (c >= 0 && r >= 0 && c < g.cols && r < g.rows && !taken.has(`${c},${r}`))
                        return [c, r];
                }
            }
        }
        return [col, row];
    }

    // ---- Selection ----

    _setSelected(item, selected) {
        if (selected) {
            this._selected.add(item);
            item.actor.add_style_pseudo_class('selected');
            this._iconBox.set_child_above_sibling(item.actor, null);
        } else {
            this._selected.delete(item);
            item.actor.remove_style_pseudo_class('selected');
        }
        // Selected icons show their full name; others are trimmed to one line.
        item.label.clutter_text.line_wrap = selected;
        item.label.clutter_text.ellipsize = selected ? Pango.EllipsizeMode.NONE : Pango.EllipsizeMode.END;
    }

    _clearSelection() {
        for (const item of [...this._selected])
            this._setSelected(item, false);
    }

    // ---- Mouse ----

    _onIconPress(item, event) {
        const button = event.get_button();
        const ctrl = (event.get_state() & Clutter.ModifierType.CONTROL_MASK) !== 0;

        if (button === 1) {
            if (event.get_click_count() >= 2) {
                this._open(item);
                return STOP;
            }
            if (ctrl) {
                this._setSelected(item, !this._selected.has(item));
                return STOP;
            }
            if (!this._selected.has(item)) {
                this._clearSelection();
                this._setSelected(item, true);
            }
            const [x, y] = event.get_coords();
            this._drag = {
                startX: x,
                startY: y,
                moved: false,
                items: [...this._selected].map(it => ({item: it, x: it.actor.x, y: it.actor.y})),
            };
            this._grab = global.stage.grab(item.actor);
            return STOP;
        }
        if (button === 3) {
            if (!this._selected.has(item)) {
                this._clearSelection();
                this._setSelected(item, true);
            }
            this._showIconMenu(event);
            return STOP;
        }
        return PROPAGATE;
    }

    _onLayerPress(event) {
        const button = event.get_button();
        if (button === 1) {
            const ctrl = (event.get_state() & Clutter.ModifierType.CONTROL_MASK) !== 0;
            if (!ctrl)
                this._clearSelection();
            const [x, y] = event.get_coords();
            const lx = x - this._layer.x, ly = y - this._layer.y;
            this._band = {x0: lx, y0: ly, base: new Set(this._selected)};
            this._bandActor.set_position(lx, ly);
            this._bandActor.set_size(0, 0);
            this._bandActor.show();
            this._grab = global.stage.grab(this._layer);
            return STOP;
        }
        if (button === 3) {
            this._clearSelection();
            this._showDesktopMenu(event);
            return STOP;
        }
        return PROPAGATE;
    }

    _onMotion(event) {
        const [x, y] = event.get_coords();
        if (this._drag) {
            const dx = x - this._drag.startX, dy = y - this._drag.startY;
            if (!this._drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD)
                return STOP;
            this._drag.moved = true;
            for (const d of this._drag.items)
                d.item.actor.set_position(d.x + dx, d.y + dy);
            return STOP;
        }
        if (this._band) {
            const lx = x - this._layer.x, ly = y - this._layer.y;
            const x1 = Math.min(lx, this._band.x0), y1 = Math.min(ly, this._band.y0);
            const x2 = Math.max(lx, this._band.x0), y2 = Math.max(ly, this._band.y0);
            this._bandActor.set_position(x1, y1);
            this._bandActor.set_size(x2 - x1, y2 - y1);
            for (const item of this._icons) {
                const a = item.actor;
                const hit = a.x < x2 && a.x + a.width > x1 && a.y < y2 && a.y + a.height > y1;
                const want = hit || this._band.base.has(item);
                if (want !== this._selected.has(item))
                    this._setSelected(item, want);
            }
            return STOP;
        }
        return PROPAGATE;
    }

    _onRelease(_event) {
        if (this._drag) {
            const drag = this._drag;
            this._drag = null;
            this._endGrab();
            if (drag.moved)
                this._drop(drag);
            return STOP;
        }
        if (this._band) {
            this._band = null;
            this._bandActor.hide();
            this._endGrab();
            return STOP;
        }
        return PROPAGATE;
    }

    _endGrab() {
        this._grab?.dismiss();
        this._grab = null;
    }

    _drop(drag) {
        const g = this._geometry();
        const moving = new Set(drag.items.map(d => d.item));
        const taken = new Set(this._icons.filter(i => !moving.has(i)).map(i => `${i.col},${i.row}`));
        const clamp = (v, max) => Math.max(0, Math.min(max, v));

        for (const d of drag.items) {
            const a = d.item.actor;
            let col = clamp(Math.round((a.x - g.ox - 4) / CELL_W), g.cols - 1);
            let row = clamp(Math.round((a.y - g.oy) / CELL_H), g.rows - 1);
            [col, row] = this._nearestFree(col, row, taken, g);
            d.item.col = col;
            d.item.row = row;
            taken.add(`${col},${row}`);
            this._place(d.item, g);
        }
        // Freeze the whole layout so nothing jumps around later.
        for (const item of this._icons)
            this._positions[item.name] = [item.col, item.row];
        this._savePositions();
    }

    // ---- Actions ----

    _open(item) {
        try {
            if (item.appInfo)
                item.appInfo.launch([], launchContext());
            else
                Gio.AppInfo.launch_default_for_uri(item.file.get_uri(), launchContext());
        } catch (e) {
            notifyError(`Couldn't open ${item.name}: ${e.message}`);
        }
    }

    _newFolder() {
        let name = 'New Folder';
        for (let n = 2; this._dir.get_child(name).query_exists(null); n++)
            name = `New Folder (${n})`;
        try {
            this._dir.get_child(name).make_directory(null);
        } catch (e) {
            notifyError(`Couldn't create a folder: ${e.message}`);
        }
    }

    _popupAt(event, build) {
        const [x, y] = event.get_coords();
        Main.layoutManager.setDummyCursorGeometry(x, y, 0, 0);
        const menu = new PopupMenu.PopupMenu(Main.layoutManager.dummyCursor, 0, St.Side.TOP);
        Main.uiGroup.add_child(menu.actor);
        menu.actor.hide();
        this._menuManager.addMenu(menu);
        build(menu);

        let destroyed = false;
        menu.connect('open-state-changed', (_m, open) => {
            if (open || destroyed)
                return;
            destroyed = true;
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                menu.destroy();
                return GLib.SOURCE_REMOVE;
            });
        });
        menu.open(BoxPointer.PopupAnimation.NONE);
    }

    _showIconMenu(event) {
        const items = [...this._selected];
        this._popupAt(event, menu => {
            menu.addAction('Open', () => items.forEach(item => this._open(item)));
            menu.addAction('Show in Files', () => openUri(this._dir.get_uri()));
            menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
            menu.addAction(items.length > 1 ? `Move ${items.length} items to Trash` : 'Move to Trash', () => {
                for (const item of items) {
                    try {
                        item.file.trash(null);
                    } catch (e) {
                        notifyError(`Couldn't move ${item.name} to the trash: ${e.message}`);
                    }
                }
            });
        });
    }

    _showDesktopMenu(event) {
        this._popupAt(event, menu => {
            menu.addAction('Arrange icons by name', () => {
                this._positions = {};
                this._savePositions();
                this._relayout();
            });
            menu.addAction('Refresh', () => this._reload());
            menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
            menu.addAction('New folder', () => this._newFolder());
            menu.addAction('Open Desktop folder', () => openUri(this._dir.get_uri()));
            menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
            menu.addAction('Change background…', () => spawn('gnome-control-center background'));
            menu.addAction('Display settings…', () => spawn('gnome-control-center display'));
        });
    }

    destroy() {
        this._endGrab();
        if (this._reloadId)
            GLib.source_remove(this._reloadId);
        this._monitor?.cancel();
        this._signals.forEach(([obj, id]) => obj.disconnect(id));
        this._signals = [];
        this._layer.destroy();
    }
}
