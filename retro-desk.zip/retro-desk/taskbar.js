import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as BoxPointer from 'resource:///org/gnome/shell/ui/boxpointer.js';
import * as AppFavorites from 'resource:///org/gnome/shell/ui/appFavorites.js';

import {launchApp, isMaximized, maximize, unmaximize, spawn} from './utils.js';

const TASK_TYPES = [Meta.WindowType.NORMAL, Meta.WindowType.DIALOG];
const HOLD_TIME = 1000;        // ms to hold before an icon can be moved
const HOLD_MOVE_TOLERANCE = 10; // moving further than this before then cancels the hold

// Hold a button down for one second and it "lifts" so you can drag it
// left or right. A normal click or tap never moves anything.
function makeReorderable(box, button, {onStart = () => {}, onDrop = () => {}} = {}) {
    let press = null;
    let holdId = 0;
    let grab = null;
    let dragging = false;

    const cancelHold = () => {
        if (holdId) {
            GLib.source_remove(holdId);
            holdId = 0;
        }
    };

    const startDrag = () => {
        holdId = 0;
        dragging = true;
        button.fake_release(); // the press no longer counts as a click
        grab = global.stage.grab(button);
        button.add_style_pseudo_class('dragging');
        onStart();
        return GLib.SOURCE_REMOVE;
    };

    button.connect('button-press-event', (_a, event) => {
        if (event.get_button() !== 1)
            return Clutter.EVENT_PROPAGATE;
        press = event.get_coords();
        cancelHold();
        holdId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, HOLD_TIME, startDrag);
        return Clutter.EVENT_PROPAGATE;
    });

    button.connect('motion-event', (_a, event) => {
        const [x, y] = event.get_coords();
        if (!dragging) {
            if (holdId && press && Math.hypot(x - press[0], y - press[1]) > HOLD_MOVE_TOLERANCE)
                cancelHold();
            return Clutter.EVENT_PROPAGATE;
        }
        const [boxX] = box.get_transformed_position();
        const others = box.get_children().filter(c => c !== button && c.visible);
        const index = others.filter(c => boxX + c.x + c.width / 2 < x).length;
        if (box.get_children().indexOf(button) !== index)
            box.set_child_at_index(button, index);
        return Clutter.EVENT_STOP;
    });

    button.connect('button-release-event', () => {
        cancelHold();
        press = null;
        if (!dragging)
            return Clutter.EVENT_PROPAGATE;
        dragging = false;
        grab?.dismiss();
        grab = null;
        button.remove_style_pseudo_class('dragging');
        onDrop(box.get_children().indexOf(button));
        return Clutter.EVENT_STOP;
    });

    button.connect('destroy', () => {
        cancelHold();
        grab?.dismiss();
        grab = null;
    });
}

export class Taskbar {
    constructor(settings, startMenu, theme) {
        this._settings = settings;
        this._startMenu = startMenu;
        this._signals = [];
        this._winSignals = new Map();
        this._adopted = null;
        this._rightAddedId = 0;
        this._minimizedByShowDesktop = null;
        this._rebuildId = 0;
        this._taskOrder = [];
        this._dragging = false;

        this.actor = new St.BoxLayout({style_class: 'retro-taskbar', reactive: true});
        theme.addRoot(this.actor);

        // Start button (icon and text come from settings)
        const startContent = new St.BoxLayout({style_class: 'retro-start-content'});
        this._startIcon = new St.Icon({style_class: 'retro-start-icon'});
        this._startLabel = new St.Label({
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'retro-start-label',
        });
        startContent.add_child(this._startIcon);
        startContent.add_child(this._startLabel);
        this._syncStartButton();
        this._startButton = new St.Button({
            style_class: 'retro-start-button',
            child: startContent,
            y_expand: true,
        });
        this._startButton.connect('clicked', () => this._startMenu.toggle());
        startMenu.setStartButton(this._startButton);
        this.actor.add_child(this._startButton);

        // Quick launch (uses GNOME's favourites list)
        this._quickLaunch = new St.BoxLayout({
            style_class: 'retro-quicklaunch',
            y_align: Clutter.ActorAlign.CENTER,
        });
        this.actor.add_child(this._quickLaunch);

        // Window buttons
        this._tasks = new St.BoxLayout({
            style_class: 'retro-tasks',
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
            clip_to_allocation: true,
        });
        this.actor.add_child(this._tasks);

        // Tray: adopted top-bar indicators, clock, show desktop
        this._tray = new St.BoxLayout({style_class: 'retro-tray', y_expand: true});
        this._trayIndicators = new St.BoxLayout({
            style_class: 'retro-tray-indicators',
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._tray.add_child(this._trayIndicators);

        this._clockLabel = new St.Label({y_align: Clutter.ActorAlign.CENTER});
        this._clock = new St.Button({
            style_class: 'retro-clock',
            child: this._clockLabel,
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._clock.connect('clicked', () => this._toggleClockMenu());
        this._tray.add_child(this._clock);

        const showDesktop = new St.Button({
            style_class: 'retro-show-desktop',
            child: new St.Icon({icon_name: 'user-desktop-symbolic', icon_size: 16}),
            y_expand: true,
        });
        showDesktop.connect('clicked', () => this._toggleShowDesktop());
        this._tray.add_child(showDesktop);
        this.actor.add_child(this._tray);

        Main.layoutManager.addChrome(this.actor, {affectsStruts: true, trackFullscreen: true});
        this._menuManager = new PopupMenu.PopupMenuManager(this.actor);

        // Clock popup
        this._clockMenu = new PopupMenu.PopupMenu(this._clock, 0.5, St.Side.BOTTOM);
        this._clockDateItem = new PopupMenu.PopupMenuItem('', {reactive: false});
        this._clockMenu.addMenuItem(this._clockDateItem);
        this._clockMenu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._clockMenu.addAction('Adjust date and time…', () => spawn('gnome-control-center system'));
        Main.uiGroup.add_child(this._clockMenu.actor);
        this._clockMenu.actor.hide();
        this._menuManager.addMenu(this._clockMenu);

        this._updateClock();
        this._clockId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1, () => {
            this._updateClock();
            return GLib.SOURCE_CONTINUE;
        });

        this._connect(Main.layoutManager, 'monitors-changed', () => this._reposition());
        this._connect(this._settings, 'changed::taskbar-height', () => this._reposition());
        this._connect(this._settings, 'changed::clock-24h', () => this._updateClock());
        this._connect(this._settings, 'changed::quick-launch', () => this._rebuildQuickLaunch());
        this._connect(this._settings, 'changed::start-label', () => this._syncStartButton());
        this._connect(this._settings, 'changed::start-icon-image', () => this._syncStartButton());
        this._connect(global.display, 'window-created', (_d, win) => {
            this._trackWindow(win);
            this._queueRebuild();
        });
        this._connect(global.display, 'notify::focus-window', () => this._queueRebuild());
        this._connect(global.workspace_manager, 'active-workspace-changed', () => this._queueRebuild());
        this._connect(AppFavorites.getAppFavorites(), 'changed', () => this._rebuildQuickLaunch());
        this._connect(Shell.AppSystem.get_default(), 'installed-changed', () => this._rebuildQuickLaunch());

        for (const win of global.display.list_all_windows())
            this._trackWindow(win);

        this._reposition();
        this._rebuildQuickLaunch();
        this._rebuild();
    }

    _connect(obj, signal, callback) {
        this._signals.push([obj, obj.connect(signal, callback)]);
    }

    _syncStartButton() {
        const image = this._settings.get_string('start-icon-image').trim();
        if (image && GLib.file_test(image, GLib.FileTest.EXISTS)) {
            this._startIcon.gicon = Gio.FileIcon.new(Gio.File.new_for_path(image));
            this._startIcon.add_style_class_name('retro-start-icon-custom');
        } else {
            this._startIcon.gicon = new Gio.ThemedIcon({
                names: ['start-here-symbolic', 'view-app-grid-symbolic'],
            });
            this._startIcon.remove_style_class_name('retro-start-icon-custom');
        }
        const text = this._settings.get_string('start-label');
        this._startLabel.text = text;
        this._startLabel.visible = text.length > 0;
    }

    _reposition() {
        const monitor = Main.layoutManager.primaryMonitor;
        if (!monitor)
            return;
        const height = this._settings.get_int('taskbar-height');
        this.actor.set_position(monitor.x, monitor.y + monitor.height - height);
        this.actor.set_size(monitor.width, height);
    }

    // ---- Clock ----

    _updateClock() {
        const fmt = this._settings.get_boolean('clock-24h') ? '%H:%M' : '%-I:%M %p';
        this._clockLabel.text = GLib.DateTime.new_now_local().format(fmt);
    }

    _toggleClockMenu() {
        this._clockDateItem.label.text =
            GLib.DateTime.new_now_local().format('%A, %-d %B %Y');
        this._clockMenu.toggle();
    }

    // ---- Quick launch ----

    _rebuildQuickLaunch() {
        this._quickLaunch.destroy_all_children();
        if (!this._settings.get_boolean('quick-launch')) {
            this._quickLaunch.hide();
            return;
        }
        for (const app of AppFavorites.getAppFavorites().getFavorites()) {
            const button = new St.Button({
                style_class: 'retro-quick-button',
                child: app.create_icon_texture(20),
            });
            button.connect('clicked', () => launchApp(app));
            makeReorderable(this._quickLaunch, button, {
                onDrop: index => AppFavorites.getAppFavorites().moveFavoriteToPos(app.get_id(), index),
            });
            this._quickLaunch.add_child(button);
        }
        this._quickLaunch.visible = this._quickLaunch.get_n_children() > 0;
    }

    // ---- Window list ----

    _trackWindow(win) {
        if (this._winSignals.has(win))
            return;
        const queue = () => this._queueRebuild();
        const ids = ['notify::title', 'notify::minimized', 'workspace-changed']
            .map(signal => win.connect(signal, queue));
        ids.push(win.connect('unmanaged', () => this._untrackWindow(win)));
        this._winSignals.set(win, ids);
    }

    _untrackWindow(win, silent = false) {
        const ids = this._winSignals.get(win);
        if (!ids)
            return;
        ids.forEach(id => win.disconnect(id));
        this._winSignals.delete(win);
        this._taskOrder = this._taskOrder.filter(w => w !== win);
        if (!silent)
            this._queueRebuild();
    }

    _windows() {
        const workspace = global.workspace_manager.get_active_workspace();
        return [...this._winSignals.keys()]
            .filter(win => !win.is_skip_taskbar() &&
                TASK_TYPES.includes(win.get_window_type()) &&
                (win.is_on_all_workspaces() || win.get_workspace() === workspace))
            .sort((a, b) => {
                const pos = w => {
                    const i = this._taskOrder.indexOf(w);
                    return i < 0 ? Infinity : i;
                };
                return (pos(a) - pos(b)) || (a.get_stable_sequence() - b.get_stable_sequence());
            });
    }

    _queueRebuild() {
        if (this._rebuildId || this._dragging)
            return;
        this._rebuildId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._rebuildId = 0;
            this._rebuild();
            return GLib.SOURCE_REMOVE;
        });
    }

    _rebuild() {
        this._tasks.destroy_all_children();
        const focused = global.display.focus_window;
        for (const win of this._windows())
            this._tasks.add_child(this._makeTaskButton(win, win === focused && !win.minimized));
    }

    _makeTaskButton(win, isActive) {
        const app = Shell.WindowTracker.get_default().get_window_app(win);
        const content = new St.BoxLayout({style_class: 'retro-task-content'});
        content.add_child(app
            ? app.create_icon_texture(16)
            : new St.Icon({icon_name: 'application-x-executable', icon_size: 16}));
        content.add_child(new St.Label({
            text: win.get_title() ?? app?.get_name() ?? '',
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'retro-task-label',
        }));

        const button = new St.Button({
            style_class: 'retro-task',
            child: content,
            button_mask: St.ButtonMask.ONE | St.ButtonMask.TWO | St.ButtonMask.THREE,
        });
        if (isActive)
            button.add_style_pseudo_class('current');
        button._retroWindow = win;
        makeReorderable(this._tasks, button, {
            onStart: () => {
                this._dragging = true;
            },
            onDrop: () => {
                this._dragging = false;
                this._taskOrder = this._tasks.get_children()
                    .map(b => b._retroWindow)
                    .filter(Boolean);
                this._queueRebuild();
            },
        });

        button.connect('clicked', (_b, clicked) => {
            const time = global.get_current_time();
            if (clicked === 1) {
                if (win.has_focus() && !win.minimized)
                    win.minimize();
                else
                    win.activate(time);
            } else if (clicked === 2) {
                win.delete(time);
            } else if (clicked === 3) {
                this._openWindowMenu(button, win);
            }
        });
        return button;
    }

    _openWindowMenu(button, win) {
        const menu = new PopupMenu.PopupMenu(button, 0.5, St.Side.BOTTOM);
        Main.uiGroup.add_child(menu.actor);
        menu.actor.hide();
        this._menuManager.addMenu(menu);

        const now = () => global.get_current_time();
        menu.addAction('Restore', () => {
            if (win.minimized)
                win.unminimize();
            else if (isMaximized(win))
                unmaximize(win);
            win.activate(now());
        });
        menu.addAction('Minimize', () => win.minimize());
        menu.addAction('Maximize', () => {
            maximize(win);
            win.activate(now());
        });
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        menu.addAction('Close', () => win.delete(now()));

        let destroyed = false;
        const destroyLater = () => {
            if (destroyed)
                return;
            destroyed = true;
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                menu.destroy();
                return GLib.SOURCE_REMOVE;
            });
        };
        menu.connect('open-state-changed', (_m, open) => {
            if (!open)
                destroyLater();
        });
        button.connect('destroy', () => menu.close());
        menu.open(BoxPointer.PopupAnimation.FULL);
    }

    _toggleShowDesktop() {
        if (this._minimizedByShowDesktop?.length) {
            for (const win of this._minimizedByShowDesktop) {
                if (this._winSignals.has(win))
                    win.unminimize();
            }
            this._minimizedByShowDesktop = null;
        } else {
            this._minimizedByShowDesktop = this._windows().filter(win => !win.minimized);
            this._minimizedByShowDesktop.forEach(win => win.minimize());
        }
    }

    // ---- Top-bar indicators (Wi-Fi, sound, Steam tray icons…) ----

    adoptPanelIndicators(on) {
        const right = Main.panel._rightBox;
        if (on && !this._adopted) {
            this._adopted = [];
            for (const child of right.get_children())
                this._adopt(child);
            this._rightAddedId = right.connect('child-added', (_box, child) => {
                GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                    if (this._adopted && child.get_parent() === right)
                        this._adopt(child);
                    return GLib.SOURCE_REMOVE;
                });
            });
        } else if (!on && this._adopted) {
            right.disconnect(this._rightAddedId);
            this._rightAddedId = 0;
            const adopted = this._adopted;
            this._adopted = null;
            for (const {actor, id} of adopted) {
                actor.disconnect(id);
                actor.get_parent()?.remove_child(actor);
                right.add_child(actor);
            }
        }
    }

    _adopt(child) {
        child.get_parent()?.remove_child(child);
        this._trayIndicators.add_child(child);
        const entry = {actor: child, id: 0};
        entry.id = child.connect('destroy', () => {
            if (this._adopted)
                this._adopted = this._adopted.filter(e => e !== entry);
        });
        this._adopted.push(entry);
    }

    destroy() {
        this.adoptPanelIndicators(false);
        if (this._rebuildId)
            GLib.source_remove(this._rebuildId);
        if (this._clockId)
            GLib.source_remove(this._clockId);
        this._signals.forEach(([obj, id]) => obj.disconnect(id));
        this._signals = [];
        for (const win of [...this._winSignals.keys()])
            this._untrackWindow(win, true);
        this._clockMenu.destroy();
        Main.layoutManager.removeChrome(this.actor);
        this.actor.destroy();
    }
}
